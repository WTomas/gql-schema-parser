module Main where

import Parser

main :: IO ()
main = do
  putStr "Hello Haskell!"